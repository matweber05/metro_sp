
  # Untitled

  This is a code bundle for Untitled. The original project is available at https://www.figma.com/design/QW76cFkHbh9R0MqGC0jvON/Untitled.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  